<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Franklin ngangu simbi </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Franklin ngangu " name="keywords">
    <meta content="Franklin ngangu" name="description">

    <!-- Favicon -->
    <link href="img/M (2).jpg" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">

    
    <link href="css/style.css" rel="stylesheet">
 <!-- our chatlive start  -->

<div class="wa-widget">
  <!-- Chat Box -->
  <div class="wa-chatbox" id="waChatBox">
    <div class="wa-header">
      <div class="wa-user">
        <img src="img/we.png" alt="Bot Avatar">
        <div>
          <h4>Franklin Assistant</h4>
          <span>Online</span>
        </div>
      </div>
      <button onclick="hideChat()" class="wa-close" aria-label="Close chat window">&times;</button>
    </div>

    <div class="wa-body">
      <div class="wa-message received">
        <p>🤖 Hello! I'm Franklin's assistant. How can I help you today?</p>
      </div>
    </div>

    <div class="wa-footer">
      <a href="https://wa.me/+27842092759" target="_blank" class="wa-start-chat">
        💬 Click to chat
      </a>
    </div>
  </div>

  <!-- Floating Robot Button (Styled like a Robot Head) -->
  <div class="wa-float-btn" onclick="toggleChat()" aria-label="Open chat assistant">
    <div class="robot-face">
      <div class="robot-eyes">
        <span class="eye left"></span>
        <span class="eye right"></span>
      </div>
      <div class="robot-mouth"></div>
    </div>
  </div>
</div>

<!-- ===================== STYLES ===================== -->
<style>
.wa-widget {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Chatbox */
.wa-chatbox {
  width: 330px;
  position: fixed;
  bottom: 100px;
  right: 20px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  overflow: hidden;
  display: none;
  flex-direction: column;
  animation: fadeInUp 0.3s ease-in-out;
  z-index: 1000;
}

.wa-header {
  background-color: #0b0d0fff;
  color: #fff;
  padding: 12px 15px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.wa-user {
  display: flex;
  align-items: center;
  gap: 10px;
}

.wa-user img {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  object-fit: cover;
}

.wa-user h4 {
  margin: 0;
  font-size: 16px;
}

.wa-user span {
  font-size: 12px;
  color: #e0ffe3;
}

.wa-close {
  background: none;
  border: none;
  color: #fff;
  font-size: 22px;
  cursor: pointer;
}

.wa-body {
  padding: 20px;
  background-color: #f6f6f6;
  height: 140px;
}

.wa-message {
  max-width: 85%;
  padding: 10px 15px;
  background-color: #e1ffc7;
  border-radius: 10px 10px 10px 0;
  margin-bottom: 10px;
  font-size: 14px;
  color: #333;
}

.wa-footer {
  padding: 15px;
  text-align: center;
  background: #fff;
}

.wa-start-chat {
  background: #131614ff;
  color: white;
  text-decoration: none;
  padding: 10px 20px;
  font-weight: bold;
  border-radius: 25px;
  transition: background 0.3s;
}

.wa-start-chat:hover {
  background: #050505ff;
}

/* Floating Robot Button */
.wa-float-btn {
  position: fixed;
  bottom: 90px;
  right: 20px;
  cursor: pointer;
  z-index: 1001;
  animation: bounce 2s infinite;
}

/* Robot Design */
.robot-face {
  width: 64px;
  height: 64px;
  background: #1e90ff;
  border-radius: 50%;
  position: relative;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.robot-eyes {
  display: flex;
  justify-content: space-between;
  padding: 16px 14px 0;
}

.eye {
  width: 10px;
  height: 10px;
  background: white;
  border-radius: 50%;
}

.robot-mouth {
  width: 24px;
  height: 4px;
  background: #fff;
  border-radius: 2px;
  position: absolute;
  bottom: 14px;
  left: 50%;
  transform: translateX(-50%);
}

/* Animations */
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}

@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Responsive */
@media screen and (max-width: 480px) {
  .wa-chatbox {
    width: 90%;
    right: 5%;
    bottom: 80px;
  }
}
</style>

<!-- ===================== SCRIPT ===================== -->
<script>
function toggleChat() {
  const chatbox = document.getElementById("waChatBox");
  chatbox.style.display = (chatbox.style.display === "flex") ? "none" : "flex";
}
function hideChat() {
  document.getElementById("waChatBox").style.display = "none";
}
</script>


<!-- Smartsupp Live Chat script 
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = 'a9114a258d63ded1bb50a58dd0d85321d998bb3f';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<noscript>Powered by <a href="https://mrblack.click/" target="_blank">Mr Black</a></noscript>





      our chat live end  -->
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="51">
    <!-- Nav Bar Start -->
    <div class="navbar navbar-expand-lg bg-light navbar-light">
        <a href="index.php" class="navbar-brand">
            <img src="img/M (2).jpg" alt="Logo" style="width: 50px; height: 50px; border-radius: 50%;">
        </a>


        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav ml-auto">
                <a href="#home" class="nav-item nav-link active">Home</a>
                <a href="#about" class="nav-item nav-link">About</a>
                <a href="#service" class="nav-item nav-link">skills</a>
                <a href="#experience" class="nav-item nav-link">Experience</a>
                <a href="#portfolio" class="nav-item nav-link">Portfolio</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </div>
    </div>
    <!-- Nav Bar End -->


    <!-- Hero Start -->
    <div class="hero" id="home">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-sm-12 col-md-6">
                    <div class="hero-content">
                        <div class="hero-text">
                            <p>I'm a </p>
                            
                            <h2></h2>
                            <div class="typed-text">
                                Final year Software Development Student,  Junior UI/UX Designer,
                                Aspiring AWS Cloud Engineer.
                            </div>



                        </div>
                        <div class="hero-btn" style="display: flex; gap: 1rem; flex-wrap: wrap;">
 
  <a class="btn" href="franklin1.pdf" target="_blank" rel="noopener noreferrer">Download CV</a>
  <a class="btn" href="school.pdf" target="_blank" rel="noopener noreferrer">See My Academic Transcript</a>
  
</div>

                    </div> 
                </div>

            </div>
        </div>
    </div>
    <!-- Hero End -->
<!-- About Start -->
<div class="about wow fadeInUp" data-wow-delay="0.1s" id="about">
    <div class="container-fluid">
        <div class="row align-items-center">
            <!-- Profile Picture Start -->
            <div class="col-lg-6 d-flex justify-content-center mb-4 mb-lg-0">
                <div class="about-img">
                    <img src="img/we.png" alt="Profile Picture"
                        class="img-fluid rounded-circle shadow-lg" style="width: 370px; height: 370px; object-fit: cover;">
                </div>
            </div>
            <!-- Profile Picture End -->

            <!-- About Content Start -->
          <div class="col-lg-6">
    <div class="about-content">
        <div class="section-header text-left mb-4">
            <p class="text-uppercase text-muted">Learn About Me</p>
        </div>
        <div class="about-text">
            <p>
                I’m a <strong>final-year Software Development</strong> student with a strong foundation in web development, database management, and object-oriented programming (OOP).
            </p>
            <p>
                Passionate about building user-centered solutions and eager to gain real-world experience through an internship or entry-level opportunity.
            </p>
            <p>
                Before entering the tech world, I gained valuable experience in the hospitality sector—from call centers to hotels—where I developed strong communication, customer service, and problem-solving skills. I’m known for being detail-oriented, reliable, punctual, and always eager to learn and grow.
            </p>
        </div>
    </div>
</div>

            <!-- About Content End -->
        </div>
<!-- Circular Skills Section Start -->
<style>
    .circular-skill-container {
        display: flex;
        flex-wrap: wrap;
        gap: 2rem;
        justify-content: center;
    }

    .circular-skill {
        display: flex;
        flex-direction: column;
        align-items: center;
        width: 150px;
    }

    .circle {
        position: relative;
        width: 100px;
        height: 100px;
    }

    .circle svg {
        transform: rotate(-90deg);
        width: 100%;
        height: 100%;
    }

    .circle circle {
        fill: none;
        stroke-width: 10;
        stroke-linecap: round;
    }

    .circle .bg {
        stroke: #eee;
    }

    .circle .progress {
        stroke: #007bff;
        stroke-dasharray: 314;
        stroke-dashoffset: 314;
        transition: stroke-dashoffset 1s;
    }

    .circle .number {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-weight: bold;
        font-size: 16px;
    }

    .skill-label {
        margin-top: 10px;
        text-align: center;
        font-size: 14px;
    }
</style>

<div class="circular-skill-container">










    <!-- Programming Languages -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 70 / 100));"/>
            </svg>
            <div class="number">70%</div>
        </div>
        <div class="skill-label"><strong>Programming Languages</strong><br>(Java, C#, JavaScript, HTML, CSS , Bootstrap , PHP)</div>
    </div>

    <!-- Version Control -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 90 / 100)); stroke: #17a2b8;"/>
            </svg>
            <div class="number">90%</div>
        </div>
        <div class="skill-label"><strong>Version Control</strong><br>(GitHub)</div>
    </div>

    <!-- Database Management -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 65 / 100)); stroke: #28a745;"/>
            </svg>
            <div class="number">65%</div>
        </div>
        <div class="skill-label"><strong>Database Management</strong><br>(MySQL, SQL Server)</div>
    </div>

    <!-- Mobile Development -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 50 / 100)); stroke: #dc3545;"/>
            </svg>
            <div class="number">50%</div>
        </div>
        <div class="skill-label"><strong>Mobile Development</strong><br>(Android - Java and  Kotlin still learning)</div>
    </div>

   
    <!-- UI/UX Design -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 80 / 100)); stroke: #ffc107;"/>
            </svg>
            <div class="number">80%</div>
        </div>
        <div class="skill-label"><strong>UI/UX Design</strong><br>(Figma, Canva)</div>
    </div>

    <!-- Development Tools -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 85 / 100)); stroke: #17a2b8;"/>
            </svg>
            <div class="number">85%</div>
        </div>
        <div class="skill-label"><strong>Development Tools</strong><br>(Visual Studio, Android Studio, Chrome DevTools)</div>
    </div>

    <!-- Teamwork & Collaboration -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 90 / 100)); stroke: #ffc107;"/>
            </svg>
            <div class="number">90%</div>
        </div>
        <div class="skill-label"><strong>Teamwork & Collaboration</strong><br>(Effective communication and collaboration)</div>
    </div>

    <!-- Time Management -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 80 / 100)); stroke: #dc3545;"/>
            </svg>
            <div class="number">80%</div>
        </div>
        <div class="skill-label"><strong>Time Management</strong><br>(Efficient task management and meeting deadlines)</div>
    </div>

    <!-- Adaptability -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 90 / 100)); stroke: #17a2b8;"/>
            </svg>
            <div class="number">90%</div>
        </div>
        <div class="skill-label"><strong>Adaptability</strong><br>(Continuous learning and adapting to technologies)</div>
    </div>

    <!-- Problem Solving -->
    <div class="circular-skill">
        <div class="circle">
            <svg>
                <circle class="bg" cx="50" cy="50" r="50"/>
                <circle class="progress" cx="50" cy="50" r="50" style="stroke-dashoffset: calc(314 - (314 * 85 / 100)); stroke: #28a745;"/>
            </svg>
            <div class="number">85%</div>
        </div>
        <div class="skill-label"><strong>Problem-Solving</strong><br>(Breaking down complex problems and finding solutions)</div>
    </div>

</div>
<!-- Circular Skills Section End -->

    </div>
</div>
<!-- About End -->

<!-- About End -->
<!-- Learn More Button Start -->
<!-- Learn More Button Start -->
<!-- Learn More Button Start -->
<div class="text-center mt-4">
    <a class="btn btn-primary py-2 px-4" href="https://mrblack.click/" target="_blank">
        👉 Explore my official business website for professional projects
    </a>
</div>
<!-- Learning Goals Section Start -->
<!-- Learning Goals Section Start -->
<!-- Learning Goals Section Start -->
<!-- Holiday Learning Plan Section Start -->
<div class="container my-5">
  <div class="card text-center shadow-sm p-4" style="border-radius: 16px;">
    <h4 class="mb-3">📘 My July Holiday Learning Plan</h4>
    <p style="font-size: 16px;">
      As a student who is always eager to grow, I’ve planned to invest my upcoming July holiday in gaining valuable cloud computing skills, especially in <strong>AWS (Amazon Web Services)</strong>.
    </p>
    <p style="font-size: 16px;">
      🌍 I’m based near the <strong>Cape Town Amazon Center</strong>, which has inspired me to explore AWS and pursue official certifications.
    </p>
    <p style="font-size: 16px;">
      My learning goals this holiday include:
      <ul class="list-unstyled">
        <li>☁️ Learn the fundamentals of cloud computing</li>
        <li>🎓 Prepare for the <strong>AWS Certified Cloud Practitioner</strong></li>
        <li>🧠 Begin the journey toward the <strong>AWS Solutions Architect – Associate</strong> certification</li>
        <li>🛠️ Build small cloud-based projects to apply what I learn</li>
      </ul>
    </p>
    <div class="mt-3">
      <a href="https://aws.amazon.com/certification/" target="_blank" class="btn btn-warning">
        🔗 Explore AWS Certification Paths
      </a>
    </div>
  </div>
</div>
<!-- Holiday Learning Plan Section End -->

<!--  Education  Goals Section start -->
<!-- Education & Certificates Section Start -->
<div class="container my-5">
  <div class="card shadow-sm p-4" style="border-radius: 16px;">
    <h4 class="text-center mb-4">🎓 Education & Certificates</h4>
    <div class="row">
      <!-- Education Section -->
      <div class="col-md-6 mb-4">
        <h5 class="text-primary">📚 Education</h5>
        <ul class="list-unstyled" style="font-size: 16px;">
          <li class="mb-3">
            <strong>CS Mafuta High School</strong><br>
            High School<br>
            <small>2010 – 2019</small>
          </li>
          <li>
            <strong>Rosebank College</strong><br>
            Diploma in Software Development<br>
            <small>2023 – Current</small>
          </li>
        </ul>
        <li>
            <strong>Ithemba college</strong><br>
            Hospitality Food and beverage<br>
            <small>2021 – 2022</small>
          </li>
        </ul>
      </div>

      <!-- Certificates Section -->
      <div class="col-md-6 mb-4">
        <h5 class="text-success">📜 Certificates</h5>
        <ul class="list-unstyled" style="font-size: 16px;">
          <li class="mb-3">
            <strong>Udemy</strong><br>
            Complete Full-Stack Web Dev Bootcamp<br>
            <small>2024 – Current (70%)</small>
          </li>
        
         <li class="mb-3">
  <strong>Udemy</strong><br>
  The Complete PHP Full Stack Web Developer Bootcamp <br>
  <small>
    <a href="https://www.udemy.com/certificate/UC-fc0491d7-561a-4dae-80e1-f3972a98dbc9/" target="_blank">
      <span class="badge bg-success">Completed</span>
    </a> – 2025
  </small>
</li>

          <li>
            <strong>AWS</strong><br>
            AWS Cloud Practitioner (CLF-C02)<br>
            <small>2025 – Current</small>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- Education & Certificates Section End -->

<!-- Education Goals Section End -->


        
        

    <!-- Service End -->


  <!-- Experience Start -->
<div class="experience" id="experience">
    <style>
        /* Remove vertical red line from timeline */
        .timeline::before {
            display: none !important;
        }

        /* Optional: Also remove any pseudo-element lines on items */
        .timeline-item::before {
            display: none !important;
        }
    </style>

    <div class="container">
        <header class="section-header text-center wow zoomIn" data-wow-delay="0.1s">
            <p>My Resume</p>
            <h2>Working Experience</h2>
        </header>
        <div class="timeline">
            <!-- Call Center Agent Experience at Chez ya Tamba Hotel -->
            <div class="timeline-item left wow slideInLeft" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">Jan 2017- Dec 2017</div>
                    <h2>French Call Intern Center Agent</h2>
                    <h4>Chez ya Tamba Hotel, Kinshasa, DR Congo</h4>
                    <p>
                        Provided French-language support to hotel guests, handling booking inquiries, complaints, and customer concerns. Focused on delivering clear communication and problem resolution.
                    </p>
                </div>
            </div>

            <!-- Supervisor at Chez ya Tamba Hotel -->
            <div class="timeline-item right wow slideInRight" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">2018 - 2019</div>
                    <h2>Barista</h2>
                    <h4>Pple Group, City of Cape Town, Western Cape, South Africa</h4>
                    <p>
                       As a Barista at Pple Group, I was responsible for delivering exceptional customer service while preparing and serving high-quality coffee beverages and snacks. My role required strong communication skills, attention to detail, and the ability to work efficiently in a fast-paced environment.
                    </p>
                </div>
            </div>

            <!-- Waiter at Protea Hotel -->
            <div class="timeline-item left wow slideInLeft" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">Jan  2021 - Jun 2024</div>
                    <h2>Waiter </h2>
                    <h4>Protea Hotel, Cape Town, South Africa</h4>
                    <p>
                        Worked as a waiter, providing excellent customer service, ensuring that guests had a positive dining experience, and delivering food and beverages efficiently.
                    </p>
                </div>
            </div>

           
</div>
<!-- Portfolio Start -->
<section class="portfolio-section" id="portfolio" style="padding: 60px 0;">
  <div class="container">

    <!-- Section Heading -->
    <div class="section-header text-center">
      <p>My Portfolio</p>
      <h2>My Excellent Portfolio</h2>
<p class="refresh-note">
  <svg xmlns="http://www.w3.org/2000/svg" 
       width="16" height="16" fill="currentColor" 
       viewBox="0 0 16 16" style="vertical-align: middle; margin-right: 5px;">
    <path d="M8 3a5 5 0 1 1-4.546 2.914.5.5 0 1 0-.908-.418A6 6 0 1 0 8 2v1z"/>
    <path d="M8 1v2l2-1.5L8 0z"/>
  </svg>
  Please refresh the browser if necessary.
</p>

    </div>

    <!-- Filter Buttons with Click Icon -->
    <div class="filter-buttons text-center mb-4" style="position: relative; display: inline-flex; align-items: center; justify-content: center; gap: 12px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; flex-wrap: wrap;">

      <ul id="portfolio-filter" style="list-style: none; padding: 0; margin: 0; display: flex; gap: 20px; cursor: pointer; flex-wrap: wrap; justify-content: center; width: 100%; max-width: 600px;">
        <li data-filter=".filter-1" class="filter-active" style="padding: 6px 12px; border-radius: 6px; transition: background-color 0.3s;">Web and Desktop Design</li>
        <li data-filter=".filter-2" style="padding: 6px 12px; border-radius: 6px; transition: background-color 0.3s;">Mobile Apps</li>
        <li data-filter=".filter-3" style="padding: 6px 12px; border-radius: 6px; transition: background-color 0.3s;">UI/UX Design</li>
      </ul>

      <div class="click-info" aria-label="Click the categories above to filter projects" role="note" style="display: flex; align-items: center; color: #666; font-size: 14px; user-select: none; margin-top: 8px; width: 100%; max-width: 600px; justify-content: center;">
        <!-- SVG Info Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#007BFF" viewBox="0 0 16 16" style="margin-right: 6px;" aria-hidden="true" focusable="false">
          <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zM8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 .877-.252 1.082-.598l.088-.416c.066-.322.009-.428-.287-.498l-.451-.083.082-.381 2.29-.287.082-.38-.45-.083c-.294-.07-.352-.176-.288-.468l.738-3.468c.194-.897-.105-1.319-.808-1.319-.545 0-.877.252-1.082.598l-.088.416zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
        </svg>
        <span style="font-weight: 500;">Click categories above to filter projects</span>
      </div>

    </div>

    <!-- Portfolio Items -->
    <div class="portfolio-container">

      <!-- Item 1 -->
      <div class="portfolio-item filter-1" style="display: block;">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/mr.png" alt="Personal Business Website" loading="lazy"
              onclick="showPopup('Personal Business Website', 'Showcasing freelance services in web development, branding, and digital solutions.')">
          </div>
          <div class="portfolio-text">
            <h3>Personal Business Website</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/MRBLACK" target="_blank"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://mrblack.click/" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 2 -->
      <div class="portfolio-item filter-1">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/donner.png" alt="Turkish Döner Haus Website" loading="lazy"
              onclick="showPopup('Turkish Döner Haus Website', 'Developed for a restaurant. Smooth user experience and menu browsing.')">
          </div>
          <div class="portfolio-text">
            <h3>Turkish Döner Haus Website</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/TDH-MAIN" target="_blank"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://turkishdonerhaus.co.za/" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 3 -->
      <div class="portfolio-item filter-1">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/wpf.png" alt="CMCS" loading="lazy"
              onclick="showPopup('CMCS using WPF and .NET', 'A desktop app to help lecturers manage claims, with login and invoice features.')">
          </div>
          <div class="portfolio-text">
            <h3>CMCS using WPF and .NET</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/POE_of_Progpart3" target="_blank"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://www.youtube.com/watch?v=PcdzzcC-J8w" target="_blank"><i class="fab fa-youtube"></i> Demo</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 4 -->
      <div class="portfolio-item filter-1">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/d.png" alt="My Portfolio" loading="lazy"
              onclick="showPopup('My Personal Portfolio', 'Showcases my software development and design skills.')">
          </div>
          <div class="portfolio-text">
            <h3>My Personal Portfolio</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/myPortofolio02" target="_blank"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://franklinngangu.com/" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 5 -->
      <div class="portfolio-item filter-2">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/SCHOOL.png" alt="Android Budgeting App" loading="lazy"
              onclick="showPopup('Android moneyMate app', 'I worked on a Kotlin + Firebase mobile application, where I was responsible for both the UI/UX design using Figma and implementing the backend authentication logic. Initially, our team agreed to follow my Figma designs, but during development, we made a mutual decision to simplify some of the layouts. This was to support a team member who was still strengthening their skills in XML for Kotlin. The priority was collaboration and ensuring smooth progress for the whole team.')">
          </div>
          <div class="portfolio-text">
            <h3>Android moneyMate app</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/Harris0109/2.1" target="_blank"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://www.youtube.com/watch?v=nOgFPc-_uLk" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 6 -->
      <div class="portfolio-item filter-3">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/SCHOOL.png" alt="Android Figma" loading="lazy"
              onclick="showPopup('Android Figma Design', 'Designed moneyMate UI in Figma with banking and savings features.')">
          </div>
          <div class="portfolio-text">
            <h3>Android moneyMate app Figma design</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://www.figma.com/proto/EsXeZWxrerAXAwP8NQgBzr/banking-app-school?node-id=5-552&p=f" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 7 -->
      <div class="portfolio-item filter-3">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/ca.png" alt="Logo Design" loading="lazy">
          </div>
          <div class="portfolio-text">
            <h3>Logo Design made in Canva</h3>
          </div>
        </div>
      </div>

      <!-- Item 8 -->
      <div class="portfolio-item filter-3">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/didi.png" alt="Restaurant UI Figma" loading="lazy"
              onclick="showPopup('Restaurant System UI', 'I designed the UI/UX for a restaurant management system from scratch using Figma.')">
          </div>
          <div class="portfolio-text">
            <h3>Restaurant Management System Figma Design</h3>
            <div class="portfolio-links">
              <a class="btn" href="https://www.figma.com/proto/RvsVvBZj5FaxVGKzrr7F4W/Restaurant-Management-System--Copy-?node-id=2699-26" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 9 -->
      <div class="portfolio-item filter-2">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/TH.png" alt="Restaurant Website" loading="lazy"
              onclick="showPopup('Restaurant Management System', 'I am currently part of a team developing a full-stack management system as an academic project, using React for the frontend and PHP for the backend. For the mobile version, we are using Kotlin with a MySQL database. In the first semester, I focused on UI/UX design, and now I have transitioned to the role of web developer. We have already begun coding, and the project is ongoing with planned completion and presentation at the end of this semester. The final presentation will be delivered to both our academic panel and the partnering company.')">
          </div>
          <div class="portfolio-text">
            <h3>Restaurant Management System</h3>
            <div class="portfolio-links">
              <a class="btn" href="javascript:void(0);" onclick="showPopup('Coming Soon', 'GitHub repo coming soon.')"><i class="fab fa-github"></i></a>
              <a class="btn" href="https://www.figma.com/proto/RvsVvBZj5FaxVGKzrr7F4W/Restaurant-Management-System--Copy-?node-id=2699-26" target="_blank"><i class="fas fa-external-link-alt"></i></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Item 10 -->
      <div class="portfolio-item filter-3">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/T.png" alt="Group Logo" loading="lazy"
              onclick="showPopup('Logo for Group Project', 'Designed in Canva for our IT team to represent us in a school project.')">
          </div>
          <div class="portfolio-text">
            <h3>Logo Design for Group Assignment</h3>
          </div>
        </div>
      </div>

      <!-- Popup -->
      <div id="popup" style="display:none; position:fixed; top:20%; left:50%; transform:translate(-50%, -20%); background:#fff; padding:20px; border-radius:10px; box-shadow:0 0 15px rgba(0,0,0,0.3); max-width:500px; z-index:9999;">
        <h4 id="popup-title" style="margin-bottom: 10px;"></h4>
        <p id="popup-description"></p>
        <button onclick="closePopup()" style="margin-top: 10px; background:#333; color:#fff; border:none; padding:8px 16px; border-radius:6px; cursor:pointer;">Close</button>
      </div>

    </div>
  </div>
</section>

<!-- Styles -->
<style>
  .refresh-note {
  font-size: 0.9rem;
  color: #555;
  margin-top: 0.5rem;
}

  .portfolio-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 30px;
    padding: 0 15px;
  }

  .portfolio-wrap {
    border: 1px solid #eee;
    padding: 15px;
    border-radius: 12px;
    background: #fff;
    transition: transform 0.3s ease;
  }

  .portfolio-wrap:hover {
    transform: translateY(-5px);
  }

  .portfolio-img {
    width: 100%;
    height: 220px;
    overflow: hidden;
    border-radius: 10px;
  }

  .portfolio-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    cursor: pointer;
  }

  .portfolio-text h3 {
    font-size: 17px;
    margin-top: 12px;
  }

  .portfolio-links .btn {
    display: inline-block;
    margin-right: 8px;
    text-decoration: none;
    background: #f4f4f4;
    padding: 6px 10px;
    border-radius: 6px;
    color: #333;
  }

  .portfolio-links .btn:hover {
    background: #ddd;
  }

  #portfolio-filter li {
    white-space: nowrap;
    user-select: none;
  }

  #portfolio-filter li:hover {
    background-color: #e7f1ff;
    color: #007BFF;
  }

  #portfolio-filter li.filter-active {
    background-color: #007BFF;
    color: white;
  }

  /* Responsive tweaks */
  @media (max-width: 600px) {
    .portfolio-text h3 {
      font-size: 15px;
    }

    .portfolio-links .btn {
      padding: 5px 8px;
      margin-bottom: 6px;
    }

    .portfolio-img {
      height: 180px;
    }

    #portfolio-filter li {
      padding: 6px 10px !important;
      font-size: 14px;
    }

    .click-info {
      font-size: 13px !important;
      margin-top: 12px !important;
      gap: 4px !important;
    }

    .click-info svg {
      width: 16px !important;
      height: 16px !important;
      margin-right: 4px !important;
    }
  }
</style>

<!-- Script -->
<script>
  // Filtering logic
  document.querySelectorAll('#portfolio-filter li').forEach(btn => {
    btn.addEventListener('click', function () {
      const filter = this.getAttribute('data-filter');
      // Remove active class from all buttons
      document.querySelectorAll('#portfolio-filter li').forEach(el => el.classList.remove('filter-active'));
      // Add active class to clicked button
      this.classList.add('filter-active');

      // Show/Hide portfolio items
      document.querySelectorAll('.portfolio-item').forEach(item => {
        if (filter === '*') {
          item.style.display = 'block'; // show all
        } else if (item.classList.contains(filter.substring(1))) {
          item.style.display = 'block'; // show filtered items
        } else {
          item.style.display = 'none'; // hide others
        }
      });
    });
  });

  // Initialize filter on page load
  window.addEventListener('DOMContentLoaded', () => {
    const activeBtn = document.querySelector('#portfolio-filter li.filter-active');
    if (activeBtn) {
      activeBtn.click();
    }
  });

  // Popup functions
  function showPopup(title, description) {
    const popup = document.getElementById('popup');
    document.getElementById('popup-title').innerText = title;
    document.getElementById('popup-description').innerText = description;
    popup.style.display = 'block';
    document.body.classList.add('popup-active');
  }

  function closePopup() {
    const popup = document.getElementById('popup');
    popup.style.display = 'none';
    document.body.classList.remove('popup-active');
  }
</script>



    <!-- Footer Start -->
    <footer class="footer wow fadeIn" data-wow-delay="0.3s">
        <div class="container-fluid bg-dark text-light pt-5">
            <div class="container">
                <div class="row g-5">
                    <!-- Contact Info -->
                    <div class="col-lg-4 col-md-6">
                        <h4 class="text-white">Contact Information</h4>
                        <p><i class="fas fa-map-marker-alt me-2"></i>6 dr marlan crescent  Brooklyn , Cape town , SA</p>
                        <p><i class="fas fa-envelope me-2"></i>simbinagngu@gmail.com</p>
                    </div>

                    <!-- Useful Links -->
                    <div class="col-lg-4 col-md-6">
                        <h4 class="text-white">Quick Links</h4>
                        <ul class="list-unstyled">
                            <li><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                            <li><a href="index.php" class="text-light text-decoration-none">About</a></li>
                            <li><a href="index.php" class="text-light text-decoration-none">Services</a></li>
                            <li><a href="contact.php" class="text-light text-decoration-none">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12">
                        <h4 class="text-white">Follow Me</h4>
                        <div class="d-flex pt-2">
                           
                           
                            <a class="btn btn-outline-light btn-social me-2" href="https://www.linkedin.com/in/franklin-ngangu-7a376a214/" target="_blank"><i
                                    class="fab fa-linkedin-in"></i></a>
                                    <a class="btn btn-outline-light btn-social" href="https://github.com/EFTECH05" target="_blank">
  <i class="fab fa-github"></i>
</a>

                        </div>
                    </div>
                </div>

                <!-- Copyright -->
                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; 2025 All Rights Reserved. Designed by <a href="https://mrblack.click/"
                                class="text-light fw-bold">Franklin Ngangu</a>.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

    <!-- Back to top button -->
    <a href="#" class="btn back-to-top"><i class="fa fa-chevron-up"></i></a>


    <!-- Pre Loader -->
    <div id="loader" class="show">
        <div class="loader"></div>
    </div>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/typed/typed.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>